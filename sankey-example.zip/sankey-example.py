import pandas as pd
import plotly.graph_objects as go

# --- Read CSV ---
df = pd.read_csv("sankey-example.csv")

# --- Build node list automatically ---
nodes = sorted(set(df["source"]).union(df["target"]))
node_index = {name: i for i, name in enumerate(nodes)}

# --- Convert to Plotly arrays ---
source = df["source"].map(node_index)
target = df["target"].map(node_index)
value  = df["value"]

# --- Build Sankey diagram ---
fig = go.Figure(go.Sankey(
    node=dict(
        pad=20,
        thickness=18,
        label=nodes
        # no colors → Plotly defaults
    ),
    link=dict(
        source=source,
        target=target,
        value=value,
        hovertemplate="%{value:,.0f}<extra></extra>"
    )
))

fig.update_layout(
    title_text="Financial Sankey Diagram",
    font_size=11
)

fig.show()
